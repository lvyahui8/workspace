package com.sldll.cms.dao;

public class SqlServerInfo {

	public static final String DBDRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static final String DBURL = "jdbc:sqlserver://localhost:1433;databaseName=catering";
	public static final String DBUSER = "sa";
	public static final String DBPASS = "123qwe";

}
